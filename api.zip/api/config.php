<?php
// Fapshi API configuration
define('FAPSHI_API_KEY', 'FAK_TEST_cb149a5a15a7915a776a');
define('FAPSHI_API_USER', 'ebbb6b4f-49cc-42ea-8b5f-e9068b1a5a2f');
define('FAPSHI_BASE_URL', 'https://sandbox.fapshi.com');

// Base URL configuration
define('BASE_URL', '/kmerhosting'); // Ajout du préfixe pour les redirections
